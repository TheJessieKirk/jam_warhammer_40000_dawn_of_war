----------------------------------------
-- File: 'abilities\chaos_doombolt6.lua'
-- Created by: AttributeEditor v2.0
-- Note: Do NOT edit by hand!
-- (c) 2001 Relic Entertainment Inc.

GameData = Inherit([[abilities\chaos_doombolt.lua]])
MetaData = InheritMeta([[abilities\chaos_doombolt.lua]])

GameData["ability_motion_name"] = ""
GameData["area_effect"]["weapon_damage"]["armour_damage"]["morale_damage"] = 10.00000
GameData["child_ability_name"] = ""
GameData["duration_time"] = 0.50000
GameData["entity_busy_time"] = 0.00000
GameData["initial_delay_time"] = 2.90000
GameData["random_offset"] = 3.00000


MetaData["$METADATATAG"] = {desc = [[]], type = 7, category = [[]], dispval = [[]], isLocked = false, }
MetaData["$METACOLOURTAG"] = 
{

}
