----------------------------------------
-- File: 'ebps\environment\urban\cover\cover_rebar_01.lua'
-- Created by: AttributeEditor v2.0
-- Note: Do NOT edit by hand!
-- (c) 2001 Relic Entertainment Inc.

GameData = Inherit([[ebps\environment\urban\cover\cover.nil]])
MetaData = InheritMeta([[ebps\environment\urban\cover\cover.nil]])

GameData["entity_blueprint_ext"]["animator"] = "environment/urban/cover/cover_rebar_01"


MetaData["$METADATATAG"] = {desc = [[]], type = 7, category = [[]], dispval = [[]], isLocked = false, }
MetaData["$METACOLOURTAG"] = 
{

}
