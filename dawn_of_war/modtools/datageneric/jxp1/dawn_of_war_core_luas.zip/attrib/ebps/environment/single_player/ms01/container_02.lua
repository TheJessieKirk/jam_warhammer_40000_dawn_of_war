----------------------------------------
-- File: 'ebps\environment\single_player\ms01\container_02.lua'
-- Created by: AttributeEditor v2.0
-- Note: Do NOT edit by hand!
-- (c) 2001 Relic Entertainment Inc.

GameData = Inherit([[ebps\environment\single_player\ms01\ms01.nil]])
MetaData = InheritMeta([[ebps\environment\single_player\ms01\ms01.nil]])

GameData["entity_blueprint_ext"]["animator"] = "environment/sp/M01_spaceport/container_02"


MetaData["$METADATATAG"] = {desc = [[]], type = 7, category = [[]], dispval = [[]], isLocked = false, }
MetaData["$METACOLOURTAG"] = 
{

}
