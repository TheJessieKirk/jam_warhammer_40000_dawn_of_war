----------------------------------------
-- File: 'ebps\environment\single_player\ms07\gatehouse_door_01_90_mini.lua'
-- Created by: AttributeEditor v2.0
-- Note: Do NOT edit by hand!
-- (c) 2001 Relic Entertainment Inc.

GameData = Inherit([[ebps\environment\single_player\ms07\gatehouse_door_01_90.lua]])
MetaData = InheritMeta([[ebps\environment\single_player\ms07\gatehouse_door_01_90.lua]])

GameData["entity_blueprint_ext"]["animator"] = "environment/sp/m07_temple/gatehouse_door_mini_01"
GameData["entity_blueprint_ext"]["scale_x"] = 6.00000


MetaData["$METADATATAG"] = {desc = [[]], type = 7, category = [[]], dispval = [[]], isLocked = false, }
MetaData["$METACOLOURTAG"] = 
{

}
