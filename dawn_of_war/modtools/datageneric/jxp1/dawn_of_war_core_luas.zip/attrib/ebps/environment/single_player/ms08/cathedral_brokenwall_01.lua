----------------------------------------
-- File: 'ebps\environment\single_player\ms08\cathedral_brokenwall_01.lua'
-- Created by: AttributeEditor v2.0
-- Note: Do NOT edit by hand!
-- (c) 2001 Relic Entertainment Inc.

GameData = Inherit([[ebps\environment\single_player\ms08\ms08.nil]])
MetaData = InheritMeta([[ebps\environment\single_player\ms08\ms08.nil]])

GameData["entity_blueprint_ext"]["animator"] = "environment/sp/m08_cathedral/cathedral_brokenwall_01"


MetaData["$METADATATAG"] = {desc = [[]], type = 7, category = [[]], dispval = [[]], isLocked = false, }
MetaData["$METACOLOURTAG"] = 
{

}
