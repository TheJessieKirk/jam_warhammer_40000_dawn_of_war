----------------------------------------
-- File: 'ebps\environment\urban\pipes\pipes_10m_01.lua'
-- Created by: AttributeEditor v2.0
-- Note: Do NOT edit by hand!
-- (c) 2001 Relic Entertainment Inc.

GameData = Inherit([[ebps\environment\urban\pipes\pipes.nil]])
MetaData = InheritMeta([[ebps\environment\urban\pipes\pipes.nil]])

GameData["entity_blueprint_ext"]["animator"] = "environment/urban/pipes/pipes_10m_01"


MetaData["$METADATATAG"] = {desc = [[]], type = 7, category = [[]], dispval = [[]], isLocked = false, }
MetaData["$METACOLOURTAG"] = 
{

}
