----------------------------------------
-- File: 'ebps\environment\urban\citysteps_2m\citysteps_2m_straight01.lua'
-- Created by: AttributeEditor v2.0
-- Note: Do NOT edit by hand!
-- (c) 2001 Relic Entertainment Inc.

GameData = Inherit([[ebps\environment\urban\citysteps_2m\citysteps_2m.nil]])
MetaData = InheritMeta([[ebps\environment\urban\citysteps_2m\citysteps_2m.nil]])

GameData["entity_blueprint_ext"]["animator"] = "environment/urban/citysteps_2m/citysteps_2m_straight01"


MetaData["$METADATATAG"] = {desc = [[]], type = 7, category = [[]], dispval = [[]], isLocked = false, }
MetaData["$METACOLOURTAG"] = 
{

}
