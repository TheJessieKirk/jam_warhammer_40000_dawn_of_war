----------------------------------------
-- File: 'ebpextensions\sim_entity_ext.lua'
-- Created by: AttributeEditor v2.0
-- Note: Do NOT edit by hand!
-- (c) 2001 Relic Entertainment Inc.

GameData = Inherit([[ebpextensions\extension.nil]])
MetaData = InheritMeta([[ebpextensions\extension.nil]])

GameData["is_collide"] = false
GameData["is_in_spatial_bucket"] = true
GameData["no_rotate"] = false


MetaData["$METADATATAG"] = {desc = [[]], type = 7, category = [[]], dispval = [[]], isLocked = false, }
MetaData["$METACOLOURTAG"] = 
{

}
MetaData["is_collide"] = {desc = [[]], type = 3, category = [[]], dispval = [[]], }
MetaData["is_in_spatial_bucket"] = {desc = [[Performance tip: Disable this for non-interactive environment objects -- they do not need to be included in proximity searches]], type = 3, category = [[]], dispval = [[]], }
MetaData["no_rotate"] = {desc = [[]], type = 3, category = [[]], dispval = [[]], }
