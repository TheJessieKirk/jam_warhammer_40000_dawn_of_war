----------------------------------------
-- File: 'abilities\sp_dxp_abilities_warbossforcefield.lua'
-- Created by: AttributeEditor v2.0
-- Note: Do NOT edit by hand!
-- (c) 2001 Relic Entertainment Inc.

GameData = Inherit([[abilities\sp_dxp_abilities.nil]])
MetaData = InheritMeta([[abilities\sp_dxp_abilities.nil]])

GameData["activation"] = Reference([[type_abilityactivation\tp_ability_activation_toggled.lua]])
GameData["duration_time"] = 29.00000
GameData["looping_event_name"] = "Orks\\Abilities\\Warboss_Force_Field"


MetaData["$METADATATAG"] = {desc = [[]], type = 7, category = [[]], dispval = [[]], isLocked = false, }
MetaData["$METACOLOURTAG"] = 
{

}
