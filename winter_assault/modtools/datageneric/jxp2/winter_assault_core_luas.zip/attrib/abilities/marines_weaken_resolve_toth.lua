----------------------------------------
-- File: 'abilities\marines_weaken_resolve_toth.lua'
-- Created by: AttributeEditor v2.0
-- Note: Do NOT edit by hand!
-- (c) 2001 Relic Entertainment Inc.

GameData = Inherit([[abilities\marines_weaken_resolve.lua]])
MetaData = InheritMeta([[abilities\marines_weaken_resolve.lua]])

GameData["requirements"]["required_1"] = Reference([[requirements\required_none.lua]])


MetaData["$METADATATAG"] = {desc = [[]], type = 7, category = [[]], dispval = [[]], isLocked = false, }
MetaData["$METACOLOURTAG"] = 
{

}
