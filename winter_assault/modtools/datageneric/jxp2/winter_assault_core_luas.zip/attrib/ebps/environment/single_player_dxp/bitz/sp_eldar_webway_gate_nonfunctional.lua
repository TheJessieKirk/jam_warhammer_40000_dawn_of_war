----------------------------------------
-- File: 'ebps\environment\single_player_dxp\bitz\sp_eldar_webway_gate_nonfunctional.lua'
-- Created by: AttributeEditor v2.0
-- Note: Do NOT edit by hand!
-- (c) 2001 Relic Entertainment Inc.

GameData = Inherit([[ebps\environment\single_player_dxp\bitz\bitz.nil]])
MetaData = InheritMeta([[ebps\environment\single_player_dxp\bitz\bitz.nil]])

GameData["entity_blueprint_ext"]["animator"] = "Races/Eldar/Structures/webway_gate"
GameData["entity_blueprint_ext"]["scale_z"] = 2.00000
GameData["type_ext"]["type_surface"] = Reference([[type_surface\tp_stone.lua]])


MetaData["$METADATATAG"] = {desc = [[]], type = 7, category = [[]], dispval = [[]], isLocked = false, }
MetaData["$METACOLOURTAG"] = 
{

}
