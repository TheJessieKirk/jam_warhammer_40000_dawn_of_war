----------------------------------------
-- File: 'ebps\environment\jungle\jungle_ruin\jungle_ruin_arch_01.lua'
-- Created by: AttributeEditor v2.0
-- Note: Do NOT edit by hand!
-- (c) 2001 Relic Entertainment Inc.

GameData = Inherit([[ebps\environment\jungle\jungle_ruin\jungle_ruin.nil]])
MetaData = InheritMeta([[ebps\environment\jungle\jungle_ruin\jungle_ruin.nil]])

GameData["entity_blueprint_ext"]["animator"] = "Environment/Jungle/Jungle_ruin/jungle_ruin_arch_01"


MetaData["$METADATATAG"] = {desc = [[]], type = 7, category = [[]], dispval = [[]], isLocked = false, }
MetaData["$METACOLOURTAG"] = 
{

}
