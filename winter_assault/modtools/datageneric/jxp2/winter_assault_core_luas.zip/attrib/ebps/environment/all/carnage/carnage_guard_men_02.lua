----------------------------------------
-- File: 'ebps\environment\all\carnage\carnage_guard_men_02.lua'
-- Created by: AttributeEditor v2.0
-- Note: Do NOT edit by hand!
-- (c) 2001 Relic Entertainment Inc.

GameData = Inherit([[ebps\environment\all\carnage\carnage.nil]])
MetaData = InheritMeta([[ebps\environment\all\carnage\carnage.nil]])

GameData["entity_blueprint_ext"]["animator"] = "environment/all/battle_dead/guard_group_2"


MetaData["$METADATATAG"] = {desc = [[]], type = 7, category = [[]], dispval = [[]], isLocked = false, }
MetaData["$METACOLOURTAG"] = 
{

}
