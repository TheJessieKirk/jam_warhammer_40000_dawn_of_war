----------------------------------------
-- File: 'ebps\environment\single_player\bitz\floating_daemon_hammer.lua'
-- Created by: AttributeEditor v2.0
-- Note: Do NOT edit by hand!
-- (c) 2001 Relic Entertainment Inc.

GameData = Inherit([[ebps\environment\single_player\bitz\bitz.nil]])
MetaData = InheritMeta([[ebps\environment\single_player\bitz\bitz.nil]])

GameData["entity_blueprint_ext"]["animator"] = "environment/sp/bitz/floating_daemon_hammer"


MetaData["$METADATATAG"] = {desc = [[]], type = 7, category = [[]], dispval = [[]], isLocked = false, }
MetaData["$METACOLOURTAG"] = 
{

}
