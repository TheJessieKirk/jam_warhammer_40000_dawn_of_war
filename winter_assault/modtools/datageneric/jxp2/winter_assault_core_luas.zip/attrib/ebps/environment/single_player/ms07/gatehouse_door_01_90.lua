----------------------------------------
-- File: 'ebps\environment\single_player\ms07\gatehouse_door_01_90.lua'
-- Created by: AttributeEditor v2.0
-- Note: Do NOT edit by hand!
-- (c) 2001 Relic Entertainment Inc.

GameData = Inherit([[ebps\environment\single_player\ms07\gatehouse_door_01.lua]])
MetaData = InheritMeta([[ebps\environment\single_player\ms07\gatehouse_door_01.lua]])

GameData["structure_ext"]["orientation"] = 90.00000


MetaData["$METADATATAG"] = {desc = [[]], type = 7, category = [[]], dispval = [[]], isLocked = false, }
MetaData["$METACOLOURTAG"] = 
{

}
