----------------------------------------
-- File: 'ebps\environment\jungle\jungle_dressing\jungle_lashed_group_01.lua'
-- Created by: AttributeEditor v2.0
-- Note: Do NOT edit by hand!
-- (c) 2001 Relic Entertainment Inc.

GameData = Inherit([[ebps\environment\jungle\jungle_dressing\jungle_dressing.nil]])
MetaData = InheritMeta([[ebps\environment\jungle\jungle_dressing\jungle_dressing.nil]])

GameData["entity_blueprint_ext"]["animator"] = "environment/jungle/jungle_dressing/jungle_lashed_group_01"


MetaData["$METADATATAG"] = {desc = [[]], type = 7, category = [[]], dispval = [[]], isLocked = false, }
MetaData["$METACOLOURTAG"] = 
{

}
