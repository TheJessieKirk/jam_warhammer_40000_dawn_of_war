----------------------------------------
-- File: 'ebps\environment\gameplay\objective_beacon_01_e3demo_selectable.lua'
-- Created by: AttributeEditor v2.0
-- Note: Do NOT edit by hand!
-- (c) 2001 Relic Entertainment Inc.

GameData = Inherit([[ebps\environment\gameplay\objective_beacon_01.lua]])
MetaData = InheritMeta([[ebps\environment\gameplay\objective_beacon_01.lua]])

GameData["ui_ext"] = Reference([[ebpextensions\ui_ext.lua]])


MetaData["$METADATATAG"] = {desc = [[]], type = 7, category = [[]], dispval = [[]], isLocked = false, }
MetaData["$METACOLOURTAG"] = 
{

}
MetaData["ui_ext"] = {desc = [[]], type = 4, category = [[]], dispval = [[]], }
