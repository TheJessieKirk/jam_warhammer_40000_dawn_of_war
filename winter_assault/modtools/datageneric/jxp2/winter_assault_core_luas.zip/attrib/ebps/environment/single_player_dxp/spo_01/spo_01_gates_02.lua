----------------------------------------
-- File: 'ebps\environment\single_player_dxp\spo_01\spo_01_gates_02.lua'
-- Created by: AttributeEditor v2.0
-- Note: Do NOT edit by hand!
-- (c) 2001 Relic Entertainment Inc.

GameData = Inherit([[ebps\environment\single_player_dxp\spo_01\spo_01_gates_01.lua]])
MetaData = InheritMeta([[ebps\environment\single_player_dxp\spo_01\spo_01_gates_01.lua]])

GameData["health_ext"]["hitpoints"] = 2000.00000


MetaData["$METADATATAG"] = {desc = [[]], type = 7, category = [[]], dispval = [[]], isLocked = false, }
MetaData["$METACOLOURTAG"] = 
{

}
