----------------------------------------
-- File: 'ebps\environment\single_player_dxp\spd_03\spd_03_sacrificial_pit_01.lua'
-- Created by: AttributeEditor v2.0
-- Note: Do NOT edit by hand!
-- (c) 2001 Relic Entertainment Inc.

GameData = Inherit([[ebps\environment\single_player_dxp\spd_03\spd_03.nil]])
MetaData = InheritMeta([[ebps\environment\single_player_dxp\spd_03\spd_03.nil]])

GameData["entity_blueprint_ext"]["animator"] = "environment/single_player_dxp/spd_03/spd_03_sacrificial_pit_01"
GameData["structure_ext"] = Reference([[ebpextensions\structure_ext.lua]])
GameData["structure_ext"]["control_structure_is"] = true
GameData["structure_ext"]["control_structure_radius"] = 50.00000


MetaData["$METADATATAG"] = {desc = [[]], type = 7, category = [[]], dispval = [[]], isLocked = false, }
MetaData["$METACOLOURTAG"] = 
{

}
MetaData["structure_ext"] = {desc = [[]], type = 4, category = [[]], dispval = [[]], }
