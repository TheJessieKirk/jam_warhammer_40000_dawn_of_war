----------------------------------------
-- File: 'ebps\environment\blood_pulse_audio_warning_01.lua'
-- Created by: AttributeEditor v2.0
-- Note: Do NOT edit by hand!
-- (c) 2001 Relic Entertainment Inc.

GameData = Inherit([[ebps\environment\cs_stronghold.lua]])
MetaData = InheritMeta([[ebps\environment\cs_stronghold.lua]])

GameData["entity_blueprint_ext"]["animator"] = "environment\\SP_DXP2\\cs_stronghold\\blood_pulse_audio_warning"
GameData["entity_blueprint_ext"]["minimum_update_radius"] = 400.00000
GameData["sim_entity_ext"]["is_in_spatial_bucket"] = false


MetaData["$METADATATAG"] = {desc = [[]], type = 7, category = [[]], dispval = [[]], isLocked = false, }
MetaData["$METACOLOURTAG"] = 
{

}
