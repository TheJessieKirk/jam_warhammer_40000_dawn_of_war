----------------------------------------
-- File: 'abilities\guard_let_it_burn_child_1.lua'
-- Created by: AttributeEditor v2.0
-- Note: Do NOT edit by hand!
-- (c) 2001 Relic Entertainment Inc.

GameData = Inherit([[abilities\guard_let_it_burn.lua]])
MetaData = InheritMeta([[abilities\guard_let_it_burn.lua]])

GameData["ability_motion_name"] = ""
GameData["area_effect"]["weapon_damage"]["armour_damage"]["min_damage"] = 50.00000
GameData["child_ability_name"] = "guard_let_it_burn_child_2"
GameData["duration_time"] = 0.00000
GameData["entity_busy_time"] = 0.00000
GameData["initial_delay_time"] = 3.00000
GameData["requirements"]["required_1"] = Reference([[requirements\required_none.lua]])


MetaData["$METADATATAG"] = {desc = [[]], type = 7, category = [[]], dispval = [[]], isLocked = false, }
MetaData["$METACOLOURTAG"] = 
{

}
