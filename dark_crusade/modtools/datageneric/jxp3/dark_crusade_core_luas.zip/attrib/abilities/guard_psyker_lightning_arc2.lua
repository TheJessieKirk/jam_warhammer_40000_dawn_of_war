----------------------------------------
-- File: 'abilities\guard_psyker_lightning_arc2.lua'
-- Created by: AttributeEditor v2.0
-- Note: Do NOT edit by hand!
-- (c) 2001 Relic Entertainment Inc.

GameData = Inherit([[abilities\guard_psyker_lightning_arc.lua]])
MetaData = InheritMeta([[abilities\guard_psyker_lightning_arc.lua]])

GameData["area_effect"]["weapon_damage"]["armour_damage"]["max_damage"] = 250.00000
GameData["area_effect"]["weapon_damage"]["armour_damage"]["min_damage"] = 250.00000
GameData["area_effect"]["weapon_damage"]["armour_damage"]["min_damage_value"] = 250.00000
GameData["caster_damage"]["morale_damage"] = 0.00000
GameData["child_ability_name"] = ""
GameData["child_range"] = 0.00000
GameData["initial_delay_time"] = 3.00000


MetaData["$METADATATAG"] = {desc = [[]], type = 7, category = [[]], dispval = [[]], isLocked = false, }
MetaData["$METACOLOURTAG"] = 
{

}
