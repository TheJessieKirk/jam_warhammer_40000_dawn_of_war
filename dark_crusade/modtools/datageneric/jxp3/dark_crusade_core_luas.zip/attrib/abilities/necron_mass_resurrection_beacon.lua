----------------------------------------
-- File: 'abilities\necron_mass_resurrection_beacon.lua'
-- Created by: AttributeEditor v2.0
-- Note: Do NOT edit by hand!
-- (c) 2001 Relic Entertainment Inc.

GameData = Inherit([[abilities\necron_mass_resurrection.lua]])
MetaData = InheritMeta([[abilities\necron_mass_resurrection.lua]])

GameData["area_effect"]["area_effect_information"]["radius"] = 35.00000
GameData["looping_event_name"] = "Tau/Abilities/Mark_Target_stealth"
GameData["recharge_time"] = 1.00000
GameData["requirements"]["required_1"] = Reference([[requirements\required_none.lua]])
GameData["ui_info"]["help_text_list"]["text_02"] = "$575450"
GameData["ui_info"]["help_text_list"]["text_03"] = "$0"


MetaData["$METADATATAG"] = {desc = [[]], type = 7, category = [[]], dispval = [[]], isLocked = false, rangeStart = 575450, rangeEnd = 575499, }
MetaData["$METACOLOURTAG"] = 
{

}
