----------------------------------------
-- File: 'abilities\eldar_psychic_storm_stronghold_sp.lua'
-- Created by: AttributeEditor v2.0
-- Note: Do NOT edit by hand!
-- (c) 2001 Relic Entertainment Inc.

GameData = Inherit([[abilities\eldar_psychic_storm.lua]])
MetaData = InheritMeta([[abilities\eldar_psychic_storm.lua]])

GameData["area_effect"]["weapon_damage"]["armour_damage"]["max_damage"] = 52.00000
GameData["area_effect"]["weapon_damage"]["armour_damage"]["min_damage"] = 23.00000


MetaData["$METADATATAG"] = {desc = [[]], type = 7, category = [[]], dispval = [[]], isLocked = false, }
MetaData["$METACOLOURTAG"] = 
{

}
