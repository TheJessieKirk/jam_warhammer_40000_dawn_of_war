----------------------------------------
-- File: 'abilities\necron_mass_resurrection_beacon2.lua'
-- Created by: AttributeEditor v2.0
-- Note: Do NOT edit by hand!
-- (c) 2001 Relic Entertainment Inc.

GameData = Inherit([[abilities\necron_mass_resurrection_beacon.lua]])
MetaData = InheritMeta([[abilities\necron_mass_resurrection_beacon.lua]])

GameData["area_effect"]["area_effect_information"]["radius"] = 500.00000


MetaData["$METADATATAG"] = {desc = [[]], type = 7, category = [[]], dispval = [[]], isLocked = false, }
MetaData["$METACOLOURTAG"] = 
{

}
