----------------------------------------
-- File: 'abilities\guard_strafing_run_children_29.lua'
-- Created by: AttributeEditor v2.0
-- Note: Do NOT edit by hand!
-- (c) 2001 Relic Entertainment Inc.

GameData = Inherit([[abilities\guard_strafing_run_children.lua]])
MetaData = InheritMeta([[abilities\guard_strafing_run_children.lua]])

GameData["anticipation_event_name"] = "Guard\\Abilities\\Strafe_pre_hit_4"
GameData["child_ability_name"] = "guard_strafing_run_children_30"
GameData["initial_delay_time"] = 12.62500


MetaData["$METADATATAG"] = {desc = [[]], type = 7, category = [[]], dispval = [[]], isLocked = false, }
MetaData["$METACOLOURTAG"] = 
{

}
