----------------------------------------
-- File: 'abilities\necron_wraith_phase_shift_advance_sp.lua'
-- Created by: AttributeEditor v2.0
-- Note: Do NOT edit by hand!
-- (c) 2001 Relic Entertainment Inc.

GameData = Inherit([[abilities\necron_wraith_phase_shift.lua]])
MetaData = InheritMeta([[abilities\necron_wraith_phase_shift.lua]])

GameData["duration_time"] = 15.00000
GameData["requirements"]["required_1"] = Reference([[requirements\required_none.lua]])
GameData["requirements"]["required_10"] = Reference([[requirements\required_none.lua]])


MetaData["$METADATATAG"] = {desc = [[]], type = 7, category = [[]], dispval = [[]], isLocked = false, }
MetaData["$METACOLOURTAG"] = 
{

}
