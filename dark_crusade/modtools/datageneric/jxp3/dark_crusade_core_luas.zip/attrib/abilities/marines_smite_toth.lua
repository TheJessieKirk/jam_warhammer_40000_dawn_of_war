----------------------------------------
-- File: 'abilities\marines_smite_toth.lua'
-- Created by: AttributeEditor v2.0
-- Note: Do NOT edit by hand!
-- (c) 2001 Relic Entertainment Inc.

GameData = Inherit([[abilities\marines_smite.lua]])
MetaData = InheritMeta([[abilities\marines_smite.lua]])

GameData["ui_info"]["help_text_list"]["text_01"] = "$0"


MetaData["$METADATATAG"] = {desc = [[]], type = 7, category = [[]], dispval = [[]], isLocked = false, }
MetaData["$METACOLOURTAG"] = 
{

}
