----------------------------------------
-- File: 'abilities\necron_chronometron_child_6.lua'
-- Created by: AttributeEditor v2.0
-- Note: Do NOT edit by hand!
-- (c) 2001 Relic Entertainment Inc.

GameData = Inherit([[abilities\necron_chronometron.lua]])
MetaData = InheritMeta([[abilities\necron_chronometron.lua]])

GameData["child_ability_name"] = "necron_chronometron_child_7"
GameData["initial_delay_time"] = 12.00000


MetaData["$METADATATAG"] = {desc = [[]], type = 7, category = [[]], dispval = [[]], isLocked = false, }
MetaData["$METACOLOURTAG"] = 
{

}
