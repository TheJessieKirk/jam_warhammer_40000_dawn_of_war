----------------------------------------
-- File: 'abilities\chaos_chains_of_torment_sp.lua'
-- Created by: AttributeEditor v2.0
-- Note: Do NOT edit by hand!
-- (c) 2001 Relic Entertainment Inc.

GameData = Inherit([[abilities\chaos_chains_of_torment.lua]])
MetaData = InheritMeta([[abilities\chaos_chains_of_torment.lua]])

GameData["area_effect"]["weapon_damage"]["armour_damage"]["max_damage"] = 0.00000
GameData["area_effect"]["weapon_damage"]["armour_damage"]["min_damage"] = 0.00000
GameData["area_effect"]["weapon_damage"]["armour_damage"]["morale_damage"] = 0.00000
GameData["duration_time"] = 10000.00000
GameData["recharge_time"] = 0.00000
GameData["requirements"]["required_1"] = Reference([[requirements\required_none.lua]])
GameData["ui_index_hint"] = 1.00000


MetaData["$METADATATAG"] = {desc = [[]], type = 7, category = [[]], dispval = [[]], isLocked = false, }
MetaData["$METACOLOURTAG"] = 
{

}
