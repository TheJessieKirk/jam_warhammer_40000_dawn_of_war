----------------------------------------
-- File: 'abilities\eldar_eldritchstorm_stronghold_sp.lua'
-- Created by: AttributeEditor v2.0
-- Note: Do NOT edit by hand!
-- (c) 2001 Relic Entertainment Inc.

GameData = Inherit([[abilities\eldar_eldritchstorm.lua]])
MetaData = InheritMeta([[abilities\eldar_eldritchstorm.lua]])

GameData["area_effect"]["weapon_damage"]["armour_damage"]["max_damage"] = 520.00000
GameData["area_effect"]["weapon_damage"]["armour_damage"]["min_damage"] = 480.00000


MetaData["$METADATATAG"] = {desc = [[]], type = 7, category = [[]], dispval = [[]], isLocked = false, }
MetaData["$METACOLOURTAG"] = 
{

}
