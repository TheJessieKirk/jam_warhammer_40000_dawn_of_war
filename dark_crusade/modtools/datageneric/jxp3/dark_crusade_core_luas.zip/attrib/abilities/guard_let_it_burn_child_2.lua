----------------------------------------
-- File: 'abilities\guard_let_it_burn_child_2.lua'
-- Created by: AttributeEditor v2.0
-- Note: Do NOT edit by hand!
-- (c) 2001 Relic Entertainment Inc.

GameData = Inherit([[abilities\guard_let_it_burn_child_1.lua]])
MetaData = InheritMeta([[abilities\guard_let_it_burn_child_1.lua]])

GameData["child_ability_name"] = "guard_let_it_burn_child_3"
GameData["initial_delay_time"] = 6.00000


MetaData["$METADATATAG"] = {desc = [[]], type = 7, category = [[]], dispval = [[]], isLocked = false, }
MetaData["$METACOLOURTAG"] = 
{

}
